building a chrome extension to get some news

check it out at https://chrome.google.com/webstore/detail/fbnews/cdnnaoaekfbccheeabjnghikfmaimocc?utm_source=gmail

feel free to file issues and contribute, I'd love to see this get better
