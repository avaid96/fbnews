building a chrome extension to get some news
